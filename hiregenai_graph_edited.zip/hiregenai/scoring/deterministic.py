"""Deterministic scoring (reproducible; never asks the LLM for a number)."""

import re


# -------------------------------------------------
# DETERMINISTIC SCORING — skills, experience, education, keywords,
# certifications, projects, and profile completeness are all computed here
# in plain Python from the LLM-extracted structured data, NOT by asking the
# LLM to invent a number. This makes scores reproducible (same input always
# gives the same output) and immune to resume text trying to talk the model
# into a higher score.
# -------------------------------------------------

# Each entry names a canonical display-independent key and only aliases that
# are equivalent to that exact skill. Related technologies intentionally stay
# separate (for example SQL/MySQL, Java/JavaScript, Git/GitHub, and
# React/React Native).
SKILL_ALIAS_GROUPS = (
    ("javascript", "javascript", "js"),
    ("typescript", "typescript", "ts"),
    ("postgresql", "postgresql", "postgres"),
    ("node.js", "nodejs", "node", "node.js"),
    ("golang", "golang", "go"),
    ("kubernetes", "kubernetes", "k8s"),
    ("amazon web services", "amazonwebservices", "aws"),
    ("google cloud platform", "googlecloudplatform", "gcp"),
    ("artificial intelligence", "artificialintelligence", "ai"),
    ("machine learning", "machinelearning", "ml"),
    ("deep learning", "deeplearning", "dl"),
    ("natural language processing", "naturallanguageprocessing", "nlp"),
    ("c#", "csharp", "c#"),
    ("objective-c", "objectivec", "objc"),
    ("continuous integration and continuous deployment",
     "continuousintegrationandcontinuousdeployment",
     "continuousintegrationcontinuousdeployment", "cicd"),
    ("user interface", "userinterface", "ui"),
    ("user experience", "userexperience", "ux"),
    ("object oriented programming", "objectorientedprogramming", "oop", "oops",
     "objectorientedprogrammingoop", "objectorientedprogrammingoops"),
    ("object oriented design", "objectorienteddesign", "ood"),
    ("data structures and algorithms", "datastructuresandalgorithms", "datastructuresalgorithms",
     "datastructureandalgorithm", "dsa"),
    ("application programming interface", "applicationprogramminginterface", "api"),
    ("rest apis", "rest", "restapi", "restapis", "restful", "restfulapi", "restfulapis"),
    ("structured query language", "structuredquerylanguage", "sql"),
    ("object relational mapping", "objectrelationalmapping", "orm"),
    ("extract transform load", "extracttransformload", "etl"),
    ("software development lifecycle", "softwaredevelopmentlifecycle", "sdlc"),
    ("quality assurance", "qualityassurance", "qa"),
    ("user acceptance testing", "useracceptancetesting", "uat"),
    ("test driven development", "testdrivendevelopment", "tdd"),
    ("behavior driven development", "behaviordrivendevelopment", "bdd"),
    ("proof of concept", "proofofconcept", "poc"),
    ("software development kit", "softwaredevelopmentkit", "sdk"),
    ("integrated development environment", "integrateddevelopmentenvironment", "ide"),
    ("customer relationship management", "customerrelationshipmanagement", "crm"),
    ("enterprise resource planning", "enterpriseresourceplanning", "erp"),
    ("search engine optimization", "searchengineoptimization", "seo"),
    ("infrastructure as code", "infrastructureascode", "iac"),
    ("identity access management", "identityaccessmanagement", "iam"),
    (".net", "net", "dotnet"),
    ("computer vision", "computervision", "cv"),
    ("react", "react", "reactjs"),
    ("vue", "vue", "vuejs"),
    ("git", "git", "gitversioncontrol"),
    ("github", "github"),
    ("mysql", "mysql"),
    ("python", "python", "python3"),
    ("java", "java", "javase", "javastandardedition"),
    ("c++", "c++", "cpp", "cplusplus"),
    ("dbms", "dbms", "databasemanagementsystem", "databasemanagementsystems"),
)


def _normalize_skill_text(skill):
    """Normalize case and separators without fuzzy or substring matching."""
    return re.sub(r"[^a-z0-9#+]", "", str(skill).lower())


_CANONICAL_SKILL_MAP = {
    _normalize_skill_text(alias): canonical
    for canonical, *aliases in SKILL_ALIAS_GROUPS
    for alias in aliases
}


def normalize_skill(skill):
    """Return the controlled canonical key for a skill, preserving unknowns."""
    normalized = _normalize_skill_text(skill)
    return _CANONICAL_SKILL_MAP.get(normalized, normalized)


def canonical_skill(skill):
    """Backward-compatible name for the shared skill normalizer."""
    return normalize_skill(skill)


def unresolved_skill_gaps(matched_skills, missing_skills):
    """Filter contradictory/duplicate gaps by canonical skill identity."""
    matched = {
        normalize_skill(skill)
        for skill in (matched_skills or [])
        if isinstance(skill, str) and skill.strip()
    }
    unresolved = []
    seen = set()
    for skill in missing_skills or []:
        if not isinstance(skill, str) or not skill.strip():
            continue
        key = normalize_skill(skill)
        if key not in matched and key not in seen:
            unresolved.append(skill)
            seen.add(key)
    return unresolved


def candidate_skill_gaps(candidate):
    """Return deterministic required-skill gaps not contradicted by resume evidence."""
    match = candidate.get("match_result") or {}
    resume_skills = (candidate.get("resume_data") or {}).get("skills", [])
    evidence = list(match.get("matched_skills") or []) + list(resume_skills or [])
    return unresolved_skill_gaps(evidence, match.get("missing_skills", []))


def score_skills(resume_skills, required_skills, preferred_skills):
    """Conservative alias-aware matching. Required skills carry full credit,
    preferred skills carry partial credit. No substring/fuzzy matching, so
    keyword stuffing (adding many unrelated buzzwords) cannot inflate a
    match that isn't a real alias/exact match, and related-but-different
    skills (Java vs JavaScript, React vs React Native) never match."""
    candidate_canon = {normalize_skill(s) for s in resume_skills if s.strip()}
    matched, missing = [], []
    for req in required_skills:
        if normalize_skill(req) in candidate_canon:
            matched.append(req)
        else:
            missing.append(req)
    pref_matched, pref_missing = [], []
    for pref in preferred_skills:
        if normalize_skill(pref) in candidate_canon:
            pref_matched.append(pref)
        else:
            pref_missing.append(pref)

    if required_skills:
        required_score = 100.0 * len(matched) / len(required_skills)
    else:
        required_score = 100.0  # nothing explicitly required — don't penalize
    if preferred_skills:
        preferred_score = 100.0 * len(pref_matched) / len(preferred_skills)
        # required skills dominate; preferred skills nudge the score
        skill_score = round(0.85 * required_score + 0.15 * preferred_score, 1)
    else:
        skill_score = round(required_score, 1)

    missing = unresolved_skill_gaps(matched, missing)
    pref_missing = unresolved_skill_gaps(pref_matched, pref_missing)
    return {
        "skill_score": max(0.0, min(100.0, skill_score)),
        "matched_skills": matched,
        "missing_skills": missing,
        "preferred_matched_skills": pref_matched,
        "preferred_missing_skills": pref_missing,
    }


def score_experience(candidate_years, required_years):
    if required_years <= 0:
        return 100.0  # JD stated no minimum — full credit, nothing to fall short of
    if candidate_years <= 0:
        return 0.0
    if candidate_years >= required_years:
        return 100.0
    return round(min(100.0, 100.0 * candidate_years / required_years), 1)


_EDUCATION_LEVELS = {"high school": 0, "other": 0, "bachelor": 1, "master": 2, "doctorate": 3}


def score_education(candidate_level, requirement_text):
    candidate_rank = _EDUCATION_LEVELS.get((candidate_level or "").strip().lower(), 0)
    req_text = (requirement_text or "").lower()
    required_rank = None
    for name, rank in [("doctorate", 3), ("phd", 3), ("master", 2), ("bachelor", 1), ("high school", 0)]:
        if name in req_text:
            required_rank = rank
            break
    if required_rank is None:
        # JD doesn't specify a clear education requirement — don't penalize
        return 100.0 if candidate_level and candidate_level.lower() != "not specified" else 60.0
    if candidate_rank >= required_rank:
        return 100.0
    gap = required_rank - candidate_rank
    return max(0.0, 100.0 - gap * 35.0)


def score_keywords(resume_keywords, resume_skills, jd_keywords):
    if not jd_keywords:
        return 100.0
    pool = {_normalize_skill_text(k) for k in (resume_keywords + resume_skills) if k.strip()}
    hits = sum(1 for k in jd_keywords if _normalize_skill_text(k) in pool)
    return round(100.0 * hits / len(jd_keywords), 1)


def score_certifications(resume_certifications, jd_keywords, jd_required_skills):
    """No JD field currently captures 'required certifications' specifically,
    so this is a best-effort, clearly-documented heuristic rather than a
    precise requirement match: certifications that textually relate to the
    JD's keywords/skills count fully; unrelated certifications still count,
    at a reduced rate, as general evidence of professional development.
    This is a known limitation — see project README / audit notes."""
    if not resume_certifications:
        return 0.0
    relevant_terms = {_normalize_skill_text(k) for k in (jd_keywords + jd_required_skills)}
    relevant = 0
    for cert in resume_certifications:
        cert_norm = _normalize_skill_text(cert)
        if any(term and term in cert_norm for term in relevant_terms):
            relevant += 1
    other = len(resume_certifications) - relevant
    score = relevant * 30 + other * 10
    return float(max(0, min(100, score)))


def score_projects(resume_projects, jd_keywords, jd_required_skills):
    if not resume_projects:
        return 0.0
    relevant_terms = {_normalize_skill_text(k) for k in (jd_keywords + jd_required_skills) if k.strip()}
    relevant = 0
    for proj in resume_projects:
        proj_norm = _normalize_skill_text(proj)
        if any(term and term in proj_norm for term in relevant_terms):
            relevant += 1
    base = min(100.0, len(resume_projects) * 15.0)  # having projects at all is worth something
    relevance_bonus = min(40.0, relevant * 20.0)
    return round(min(100.0, base * 0.6 + relevance_bonus), 1)


def score_profile_completeness(resume_data, resume_text):
    """Replaces the old 'resume_quality: formatting/clarity' concept, which
    asked the LLM to judge visual formatting from plain extracted text —
    formatting/layout information does not survive PDF/DOCX text extraction,
    so that judgement was unanswerable and effectively fabricated. This
    instead deterministically checks how complete the extracted profile is."""
    checks = [
        bool(resume_data.get("name") and resume_data["name"] != "Unknown"),
        bool(resume_data.get("email")),
        bool(resume_data.get("phone")),
        resume_data.get("experience_years", 0) > 0,
        bool(resume_data.get("education") and resume_data["education"] != "Not specified"),
        len(resume_data.get("skills", [])) >= 3,
        bool(resume_data.get("projects") or resume_data.get("certifications")),
        len((resume_text or "").strip()) >= 300,
    ]
    return round(100.0 * sum(checks) / len(checks), 1)


def compute_deterministic_breakdown(resume_data, jd_data, resume_text):
    """Runs all deterministic component scores and returns an ATSBreakdown-
    shaped dict plus the raw match details (matched/missing skills etc.)."""
    skill_result = score_skills(
        resume_data.get("skills", []),
        jd_data.get("required_skills", []),
        jd_data.get("preferred_skills", []),
    )
    experience_score = score_experience(
        resume_data.get("experience_years", 0.0),
        jd_data.get("min_experience", 0.0),
    )
    education_score = score_education(
        resume_data.get("education_level", ""),
        jd_data.get("education_requirement", ""),
    )
    keyword_score = score_keywords(
        resume_data.get("keywords", []),
        resume_data.get("skills", []),
        jd_data.get("keywords", []),
    )
    cert_score = score_certifications(
        resume_data.get("certifications", []),
        jd_data.get("keywords", []),
        jd_data.get("required_skills", []),
    )
    project_score = score_projects(
        resume_data.get("projects", []),
        jd_data.get("keywords", []),
        jd_data.get("required_skills", []),
    )
    completeness_score = score_profile_completeness(resume_data, resume_text)

    breakdown = {
        "skills": skill_result["skill_score"],
        "experience": experience_score,
        "education": education_score,
        "projects": project_score,
        "certifications": cert_score,
        "keywords": keyword_score,
        "resume_quality": completeness_score,  # kept as the same field name for compatibility; see docstring above
    }
    match_result = {
        "skill_match_score": skill_result["skill_score"],
        "experience_match_score": experience_score,
        "matched_skills": skill_result["matched_skills"],
        "missing_skills": skill_result["missing_skills"],
        # Previously computed by score_skills() but discarded here — now kept
        # so downstream views (Quick View, Why This Score?) can show
        # required vs. preferred skill match separately instead of only
        # ever seeing the required-skills numbers.
        "preferred_matched_skills": skill_result["preferred_matched_skills"],
        "preferred_missing_skills": skill_result["preferred_missing_skills"],
    }
    return breakdown, match_result
