"""Reusable UI components and chart helpers."""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import streamlit as st

from config import BREAKDOWN_LABELS
from scoring.deterministic import candidate_skill_gaps, unresolved_skill_gaps
from ui.helpers import decision_color


# -------------------------------------------------
# UI COMPONENTS
# -------------------------------------------------
def kpi_card(title, value, color="#38bdf8"):
    st.markdown(
        f"""<div class='kpi-card'>
            <div class='kpi-title'>{title}</div>
            <div class='kpi-value' style='color:{color};'>{value}</div>
        </div>""",
        unsafe_allow_html=True
    )


def _render_fig(fig):
    """Render a matplotlib figure in Streamlit and close it to free memory."""
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)


def _light_style(ax, fig):
    """Apply clean light theme to matplotlib axes and figure."""
    fig.patch.set_facecolor('#ffffff')
    ax.set_facecolor('#ffffff')
    ax.tick_params(colors='#475569', labelsize=9)
    ax.xaxis.label.set_color('#475569')
    ax.yaxis.label.set_color('#475569')
    ax.title.set_color('#0f172a')
    for spine in ax.spines.values():
        spine.set_color('#e2e8f0')


def _html_bar_chart(items, max_val, color="#38bdf8"):
    """Return HTML for a CSS bar chart. items = [(label, value), ...]"""
    if max_val == 0:
        max_val = 1
    rows = ""
    for label, val in items:
        pct = min(int(val / max_val * 100), 100)
        rows += f"""<div class='bar-row'>
            <span class='bar-label' title='{label}'>{label}</span>
            <div class='bar-track'><div class='bar-fill' style='width:{pct}%;background:{color};'>{val}</div></div>
        </div>"""
    return f"<div class='css-bar-chart'>{rows}</div>"


def _html_donut(segments, center_text="", center_sub=""):
    """Return HTML for a CSS conic-gradient donut. segments = [(label, value, color), ...]"""
    total = sum(v for _, v, _ in segments) or 1
    stops = []
    cum = 0
    for _, val, col in segments:
        start = cum / total * 360
        cum += val
        end = cum / total * 360
        stops.append(f"{col} {start:.1f}deg {end:.1f}deg")
    gradient = ", ".join(stops) if stops else "#e2e8f0 0deg 360deg"
    legend = ""
    for lbl, val, col in segments:
        pct = round(val / total * 100, 1) if total else 0
        legend += f"<div class='legend-item'><span class='legend-dot' style='background:{col};'></span>{lbl}: {val} ({pct}%)</div>"
    return f"""<div class='donut-wrap'>
        <div class='donut' style='background:conic-gradient({gradient});'>
            <div class='donut-hole'><span class='num'>{center_text}</span><span class='sub'>{center_sub}</span></div>
        </div>
        <div class='donut-legend'>{legend}</div>
    </div>"""


def render_quick_view_block(c, rank=None, total=None):
    """
    Compact, scan-in-5-seconds summary of a candidate: reuses fields already
    computed during evaluation (ats_score, match_result, ai_evaluation) —
    no new scoring, no new AI call. Used both in the Candidates page (as a
    tab) and in the Shortlist Workspace, so the same "quick read" looks and
    behaves identically everywhere it appears.
    """
    match = c.get("match_result", {})
    ai_eval = c.get("ai_evaluation", {})
    sc = c["ats_score"]
    sc_color = "#22c55e" if sc >= 70 else "#f59e0b" if sc >= 40 else "#ef4444"

    req_matched = match.get("matched_skills", [])
    req_missing = candidate_skill_gaps(c)
    pref_matched = match.get("preferred_matched_skills", [])
    pref_missing = unresolved_skill_gaps(
        pref_matched,
        match.get("preferred_missing_skills", []),
    )
    req_total = len(req_matched) + len(match.get("missing_skills", []))
    pref_total = len(pref_matched) + len(pref_missing)

    rank_html = f"<div class='stat-mini'><div class='s-val' style='color:#7c3aed;'>#{rank}{f' / {total}' if total else ''}</div><div class='s-lbl'>Rank</div></div>" if rank else ""

    st.markdown(f"""<div class='stat-row'>
        {rank_html}
        <div class='stat-mini'><div class='s-val' style='color:{sc_color};'>{sc}%</div><div class='s-lbl'>Match Score</div></div>
        <div class='stat-mini'><div class='s-val' style='color:#2563eb;'>{len(req_matched)} of {req_total}</div><div class='s-lbl'>Required Skills</div></div>
        <div class='stat-mini'><div class='s-val' style='color:#0891b2;'>{len(pref_matched)}/{pref_total or "0"}</div><div class='s-lbl'>Preferred Skills</div></div>
        <div class='stat-mini'><div class='s-val' style='color:{decision_color(c.get("recruiter_decision","Not Decided"))};'>{c.get("recruiter_decision","Not Decided")}</div><div class='s-lbl'>Decision</div></div>
    </div>""", unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**✅ Key Strengths**")
        strengths = ai_eval.get("strengths", [])[:3]
        if strengths:
            for s in strengths:
                st.markdown(f"<div style='color:#16a34a;font-size:.88rem;'>+ {s}</div>", unsafe_allow_html=True)
        else:
            st.caption("None recorded.")
    with col2:
        st.markdown("**⚠️ Key Gaps**")
        gaps = req_missing[:5]
        if gaps:
            st.markdown(", ".join(f"<span class='badge badge-red'>{g}</span>" for g in gaps), unsafe_allow_html=True)
        else:
            st.caption("No missing required skills.")

    summary = ai_eval.get("summary", "")
    if summary:
        st.caption(summary)


def render_why_score_block(c):
    """
    Plain-language breakdown of how the deterministic ats_score was built —
    reuses the same ats_breakdown/weights/match_result already computed by
    compute_deterministic_breakdown(); does not recompute or re-score
    anything. Complements (doesn't replace) the existing numeric
    'Score Breakdown' tab by turning the same numbers into a readable
    explanation plus the specific skills behind the skills score.
    """
    breakdown = c.get("ats_breakdown", {})
    weights = st.session_state.weights
    match = c.get("match_result", {})

    contributions = []
    for key in ["skills", "experience", "education", "projects", "certifications", "keywords", "resume_quality"]:
        score = breakdown.get(key, 0)
        weight = weights.get(key, 0)
        contribution = round(score * weight / 100, 2)
        contributions.append((key, score, weight, contribution))
    contributions.sort(key=lambda x: x[3], reverse=True)

    st.markdown(f"#### Final score: {c['ats_score']}%")
    st.caption(
        "Calculated as: Σ (component score × component weight) — a plain formula, "
        "not an AI judgment call. Same resume + same JD + same weights always "
        "produces the same number."
    )

    biggest = contributions[0]
    smallest = contributions[-1]
    st.markdown(
        f"**Biggest driver:** {BREAKDOWN_LABELS.get(biggest[0], biggest[0])} contributed "
        f"the most ({biggest[3]} of {c['ats_score']} points — scored {biggest[1]}% at "
        f"{biggest[2]}% weight). **Smallest driver:** "
        f"{BREAKDOWN_LABELS.get(smallest[0], smallest[0])} contributed the least "
        f"({smallest[3]} points)."
    )

    st.markdown("**Contribution by component:**")
    for key, score, weight, contribution in contributions:
        label = BREAKDOWN_LABELS.get(key, key)
        st.markdown(
            f"<div class='bar-row'><span class='bar-label' style='min-width:150px;' title='{label}'>{label}</span>"
            f"<div class='bar-track'><div class='bar-fill' style='width:{max(4, score)}%;background:#2563eb;'>"
            f"{score}%</div></div>"
            f"<span style='font-size:.75rem;color:#64748b;min-width:120px;'>× {weight}% weight = {contribution} pts</span></div>",
            unsafe_allow_html=True
        )

    st.markdown("**Required skills — what specifically matched:**")
    req_matched = match.get("matched_skills", [])
    req_missing = candidate_skill_gaps(c)
    if req_matched:
        st.markdown("✅ " + ", ".join(req_matched))
    if req_missing:
        st.markdown("❌ " + ", ".join(req_missing))
    if not req_matched and not req_missing:
        st.caption("The job description didn't list any required skills.")

    pref_matched = match.get("preferred_matched_skills", [])
    pref_missing = unresolved_skill_gaps(
        pref_matched,
        match.get("preferred_missing_skills", []),
    )
    if pref_matched or pref_missing:
        st.markdown("**Preferred (nice-to-have) skills:**")
        if pref_matched:
            st.markdown("✅ " + ", ".join(pref_matched))
        if pref_missing:
            st.markdown("❌ " + ", ".join(pref_missing))

    st.caption(
        "ℹ️ Education and Certifications use simplified heuristics rather than a precise "
        "requirement match — see the Score Breakdown tab for that caveat in full."
    )
