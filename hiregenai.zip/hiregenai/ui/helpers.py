"""Small presentational helpers."""

import base64


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def status_color(status):
    return {
        "New": "#64748b",
        "AI Evaluated": "#38bdf8",
        "Shortlisted": "#22c55e",
        "On Hold": "#f59e0b",
        "Rejected": "#ef4444",
    }.get(status, "#64748b")


def decision_color(decision):
    return {
        "Shortlist": "#22c55e",
        "On Hold": "#f59e0b",
        "Reject": "#ef4444"
    }.get(decision, "#64748b")


def get_resume_preview_html(candidate):
    file_type = candidate.get("file_type", "txt")
    content = candidate.get("file_content", b"")
    if file_type == "pdf" and content:
        b64 = base64.b64encode(content).decode()
        return f'<iframe src="data:application/pdf;base64,{b64}" width="100%" height="500px" style="border:none;"></iframe>'
    return None
