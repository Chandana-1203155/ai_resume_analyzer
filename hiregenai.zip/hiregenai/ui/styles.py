"""Global CSS for the app."""

import streamlit as st


_STYLES = """
<style>
/* ===== Light Theme ===== */
:root {
    --bg: #f8fafc;
    --surface: #ffffff;
    --border: #e2e8f0;
    --text: #1e293b;
    --muted: #64748b;
    --accent: #2563eb;
    --success: #16a34a;
    --warning: #d97706;
    --danger: #dc2626;
}

.stApp { background-color: var(--bg); }

h1, h2, h3, h4, h5, h6 { color: #0f172a !important; font-family: 'Segoe UI', sans-serif; }
p, div, span, label, .st-emotion-cache-10trblm { color: #1e293b !important; }

/* Sidebar */
section[data-testid="stSidebar"] { background-color: #ffffff; border-right: 1px solid #e2e8f0; }

/* Buttons */
.stButton button { border-radius: 8px; font-weight: 600; }

/* Section card */
.section-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 1.25rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.section-header { display:flex; align-items:center; gap:.75rem; margin-bottom:1rem; font-size:1.15rem; font-weight:700; color:#0f172a; }
.section-header .step-icon { font-size: 1.4rem; }
.section-note { color: #64748b; margin-bottom: 1rem; }

.sticky-action { position:sticky; bottom:0; left:0; width:100%; z-index:999; padding:1rem 0; background:rgba(248,250,252,.96); border-top:1px solid #e2e8f0; }
.analysis-button { width:100%; border-radius:12px; padding:1rem 1.25rem; font-size:1rem; font-weight:700; background:#2563eb; color:#fff; border:none; }
.analysis-button:disabled { opacity:.5; cursor:not-allowed; }

.empty-state-card { background:#ffffff; border:1px dashed #cbd5e1; border-radius:14px; padding:1.5rem; margin-bottom:1.5rem; color:#64748b; }
.result-card { background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:1.25rem; margin-bottom:1.5rem; }

/* Progress bar */
.stProgress .st-bo { background-color: #2563eb; }

/* ---- Dashboard Components ---- */
.dash-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:.85rem; margin-bottom:1.5rem; }
.dash-kpi { background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:1rem; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,.05); transition:transform .15s; }
.dash-kpi:hover { transform:translateY(-2px); box-shadow:0 4px 12px rgba(0,0,0,.08); }
.dash-kpi .label { color:#64748b; font-size:.75rem; text-transform:uppercase; letter-spacing:.05em; }
.dash-kpi .val { font-size:1.8rem; font-weight:800; margin-top:.1rem; }

.chart-card { background:#ffffff; border:1px solid #e2e8f0; border-radius:14px; padding:1.25rem 1.5rem; margin-bottom:1.5rem; box-shadow:0 1px 4px rgba(0,0,0,.05); }
.chart-title { color:#0f172a; font-size:1rem; font-weight:700; margin-bottom:1rem; }

/* CSS bar chart */
.css-bar-chart { display:flex; flex-direction:column; gap:.5rem; }
.bar-row { display:flex; align-items:center; gap:.6rem; }
.bar-label { color:#334155; font-size:.8rem; min-width:110px; text-align:right; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.bar-track { flex:1; height:24px; background:#f1f5f9; border-radius:6px; overflow:hidden; }
.bar-fill { height:100%; border-radius:6px; display:flex; align-items:center; justify-content:flex-end; padding-right:8px; font-size:.72rem; font-weight:700; color:#fff; transition:width .4s ease; min-width:24px; }

/* CSS donut */
.donut-wrap { display:flex; justify-content:center; align-items:center; gap:1.5rem; flex-wrap:wrap; }
.donut { width:160px; height:160px; border-radius:50%; position:relative; display:flex; align-items:center; justify-content:center; }
.donut-hole { width:85px; height:85px; border-radius:50%; background:#ffffff; display:flex; align-items:center; justify-content:center; flex-direction:column; }
.donut-hole .num { color:#0f172a; font-size:1.3rem; font-weight:800; }
.donut-hole .sub { color:#64748b; font-size:.65rem; }
.donut-legend { display:flex; flex-direction:column; gap:.4rem; }
.legend-item { display:flex; align-items:center; gap:.4rem; font-size:.8rem; color:#334155; }
.legend-dot { width:10px; height:10px; border-radius:50%; flex-shrink:0; }

/* Ranking table */
.rank-table { width:100%; border-collapse:separate; border-spacing:0; }
.rank-table th { background:#f1f5f9; color:#334155; padding:.6rem .8rem; font-size:.78rem; text-transform:uppercase; letter-spacing:.04em; text-align:left; }
.rank-table th:first-child { border-radius:8px 0 0 0; }
.rank-table th:last-child { border-radius:0 8px 0 0; }
.rank-table td { padding:.6rem .8rem; color:#1e293b; border-bottom:1px solid #f1f5f9; font-size:.85rem; }
.rank-table tr:hover td { background:#f8fafc; }
.rank-table .score-pill { display:inline-block; padding:2px 10px; border-radius:20px; font-weight:700; font-size:.78rem; }

/* Badge */
.badge { display:inline-block; padding:3px 10px; border-radius:20px; font-size:.72rem; font-weight:600; }
.badge-green { background:rgba(22,163,74,.1); color:#16a34a; }
.badge-yellow { background:rgba(217,119,6,.1); color:#d97706; }
.badge-red { background:rgba(220,38,38,.1); color:#dc2626; }
.badge-blue { background:rgba(37,99,235,.1); color:#2563eb; }

/* Two-col layout */
.dash-row { display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; margin-bottom:1.5rem; }
@media (max-width:768px) { .dash-row { grid-template-columns:1fr; } }

/* Stat mini card row */
.stat-row { display:flex; gap:1rem; flex-wrap:wrap; margin-bottom:1.5rem; }
.stat-mini { flex:1; min-width:120px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:.8rem; text-align:center; }
.stat-mini .s-val { font-size:1.15rem; font-weight:700; }
.stat-mini .s-lbl { font-size:.7rem; color:#64748b; margin-top:.15rem; }
</style>
"""


def inject_styles():
    st.markdown(_STYLES, unsafe_allow_html=True)
