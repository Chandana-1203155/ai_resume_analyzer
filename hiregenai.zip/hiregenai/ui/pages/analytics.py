"""Analytics page."""

from collections import Counter

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import streamlit as st

from ui.components import _light_style, _render_fig


def render_analytics():
    st.header("Analytics")
    candidates = st.session_state.candidates
    if not candidates:
        st.info("No data available. Evaluate candidates first to see analytics.")
        return

    scores = [c["ats_score"] for c in candidates]
    high_scorers = sum(1 for s in scores if s >= 70)
    medium_scorers = sum(1 for s in scores if 40 <= s < 70)
    low_scorers = sum(1 for s in scores if s < 40)
    shortlisted = sum(1 for c in candidates if c["recruiter_decision"] == "Shortlist")

    st.markdown(f"""<div class='dash-grid'>
        <div class='dash-kpi'><div class='label'>Total Candidates</div><div class='val' style='color:#38bdf8;'>{len(candidates)}</div></div>
        <div class='dash-kpi'><div class='label'>Highest Score</div><div class='val' style='color:#22c55e;'>{max(scores)}%</div></div>
        <div class='dash-kpi'><div class='label'>High Scorers (70+)</div><div class='val' style='color:#22c55e;'>{high_scorers}</div></div>
        <div class='dash-kpi'><div class='label'>Medium (40-70)</div><div class='val' style='color:#f59e0b;'>{medium_scorers}</div></div>
        <div class='dash-kpi'><div class='label'>Low Scorers (&lt;40)</div><div class='val' style='color:#ef4444;'>{low_scorers}</div></div>
    </div>""", unsafe_allow_html=True)

    # --- A. Hiring Funnel ---
    st.markdown("### Hiring Funnel")
    funnel_stages = ["Applied","Analyzed","Shortlisted","Recruiter Decision"]
    applied = len(candidates)
    analyzed = len(candidates)
    shortlisted_count = sum(1 for c in candidates if c.get("recruiter_decision", "Not Decided") == "Shortlist")
    decided_count = sum(1 for c in candidates
    if c.get("recruiter_decision", "Not Decided") != "Not Decided")
    funnel_values = [applied,analyzed,shortlisted_count,decided_count]
    funnel_colors = ["#3b82f6","#06b6d4","#16a34a","#64748b"]
    fig, ax = plt.subplots(figsize=(8, 4))
    _light_style(ax, fig)
    bars = ax.barh(funnel_stages[::-1], funnel_values[::-1], color=funnel_colors[::-1], height=0.6, edgecolor='none')
    for bar, val in zip(bars, funnel_values[::-1]):
        ax.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height() / 2, str(val),
                va='center', color='#334155', fontsize=11, fontweight='bold')
    ax.set_title("Recruitment Funnel", fontsize=14, fontweight='bold', pad=12)
    ax.set_xlabel("")
    ax.invert_yaxis()
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    fig.tight_layout()
    _render_fig(fig)

    # --- B. Skill Demand + C. Experience Distribution ---
    c1, c2 = st.columns(2)

    with c1:
        st.markdown("### Skill Demand Analysis")
        all_skills = []
        for c in candidates:
            all_skills.extend(c["resume_data"].get("skills", []))
        if all_skills:
            skill_counts = Counter(all_skills)
            top_skills = skill_counts.most_common(12)
            labels = [s for s, _ in top_skills]
            vals = [v for _, v in top_skills]

            fig, ax = plt.subplots(figsize=(6, 5))
            _light_style(ax, fig)
            bars = ax.barh(labels[::-1], vals[::-1], color='#3b82f6', height=0.65, edgecolor='none')
            for bar, val in zip(bars, vals[::-1]):
                ax.text(bar.get_width() + 0.15, bar.get_y() + bar.get_height() / 2, str(val),
                        va='center', color='#334155', fontsize=9, fontweight='bold')
            ax.set_title("Most Common Skills", fontsize=12, fontweight='bold', pad=10)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            fig.tight_layout()
            _render_fig(fig)

            # Missing skills
            missing_counts = Counter()
            for c in candidates:
                missing_counts.update(c["ai_evaluation"].get("missing_skills", []))
            if missing_counts:
                top_missing = missing_counts.most_common(8)
                m_labels = [s for s, _ in top_missing]
                m_vals = [v for _, v in top_missing]
                fig, ax = plt.subplots(figsize=(6, 4))
                _light_style(ax, fig)
                bars = ax.barh(m_labels[::-1], m_vals[::-1], color='#dc2626', height=0.65, edgecolor='none')
                for bar, val in zip(bars, m_vals[::-1]):
                    ax.text(bar.get_width() + 0.15, bar.get_y() + bar.get_height() / 2, str(val),
                            va='center', color='#334155', fontsize=9, fontweight='bold')
                ax.set_title("Top Skill Gaps", fontsize=12, fontweight='bold', pad=10)
                ax.spines['top'].set_visible(False)
                ax.spines['right'].set_visible(False)
                fig.tight_layout()
                _render_fig(fig)
        else:
            st.info("No skill data available.")

    with c2:
        st.markdown("### Experience Distribution")
        exp_ranges = {"0-2 Yrs": 0, "3-5 Yrs": 0, "6-10 Yrs": 0, "10+ Yrs": 0}
        for c in candidates:
            yrs = c["resume_data"].get("experience_years", 0)
            if yrs <= 2: exp_ranges["0-2 Yrs"] += 1
            elif yrs <= 5: exp_ranges["3-5 Yrs"] += 1
            elif yrs <= 10: exp_ranges["6-10 Yrs"] += 1
            else: exp_ranges["10+ Yrs"] += 1
        exp_colors = ["#3b82f6", "#16a34a", "#d97706", "#9333ea"]
        exp_vals = list(exp_ranges.values())
        exp_labels = list(exp_ranges.keys())

        fig, ax = plt.subplots(figsize=(5, 4))
        _light_style(ax, fig)
        ax.pie(
            exp_vals, labels=exp_labels, colors=exp_colors, autopct='%1.0f%%',
            startangle=90, textprops={'fontsize': 10, 'color': '#334155'}
        )
        ax.set_title("Experience Breakdown", fontsize=12, fontweight='bold', pad=10)
        fig.tight_layout()
        _render_fig(fig)

        # --- Candidate Source ---
        st.markdown("### Candidate Sources")
        source_counts = Counter(c.get("source", "Upload") for c in candidates)
        src_labels = list(source_counts.keys())
        src_vals = list(source_counts.values())
        fig, ax = plt.subplots(figsize=(6, 3.5))
        _light_style(ax, fig)
        bars = ax.bar(src_labels, src_vals, color='#3b82f6', width=0.5, edgecolor='none')
        for bar, val in zip(bars, src_vals):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2, str(val),
                    ha='center', color='#334155', fontsize=10, fontweight='bold')
        ax.set_title("Candidates by Source", fontsize=12, fontweight='bold', pad=10)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        fig.tight_layout()
        _render_fig(fig)

    # --- D. Score Distribution + E. Role Trends ---
    c3, c4 = st.columns(2)

    with c3:
        st.markdown("### Score Distribution")
        score_cats = {"High (70-100)": high_scorers, "Medium (40-69)": medium_scorers, "Low (0-39)": low_scorers}
        cat_colors = ["#16a34a", "#d97706", "#dc2626"]
        cat_vals = list(score_cats.values())
        cat_labels = list(score_cats.keys())

        fig, ax = plt.subplots(figsize=(5, 4))
        _light_style(ax, fig)
        ax.pie(
            cat_vals, labels=cat_labels, colors=cat_colors, autopct='%1.0f%%',
            startangle=90, textprops={'fontsize': 10, 'color': '#334155'}
        )
        ax.set_title("Candidate Quality Distribution", fontsize=12, fontweight='bold', pad=10)
        fig.tight_layout()
        _render_fig(fig)

        # Score histogram
        fig, ax = plt.subplots(figsize=(6, 3.5))
        _light_style(ax, fig)
        ax.hist(scores, bins=10, color='#3b82f6', edgecolor='#ffffff', linewidth=0.5)
        ax.set_xlabel("Match Score", fontsize=10)
        ax.set_ylabel("Candidates", fontsize=10)
        ax.set_title("Match Score Histogram", fontsize=12, fontweight='bold', pad=10)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        fig.tight_layout()
        _render_fig(fig)

    with c4:
        st.markdown("### Department / Role Trends")
        roles = [c["best_role"] for c in candidates if c.get("best_role")]
        if roles:
            role_counts = Counter(roles)
            r_labels = list(role_counts.keys())
            r_vals = list(role_counts.values())

            fig, ax = plt.subplots(figsize=(6, max(3.5, len(r_labels) * 0.5)))
            _light_style(ax, fig)
            bars = ax.barh(r_labels, r_vals, color='#8b5cf6', height=0.6, edgecolor='none')
            for bar, val in zip(bars, r_vals):
                ax.text(bar.get_width() + 0.15, bar.get_y() + bar.get_height() / 2, str(val),
                        va='center', color='#334155', fontsize=9, fontweight='bold')
            ax.set_title("Candidates per Role", fontsize=12, fontweight='bold', pad=10)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            fig.tight_layout()
            _render_fig(fig)

            # Role vs avg score
            role_scores = {}
            for c in candidates:
                role = c.get("best_role", "Unknown")
                if role not in role_scores:
                    role_scores[role] = []
                role_scores[role].append(c["ats_score"])
            role_avg = {r: round(sum(s) / len(s), 1) for r, s in role_scores.items()}
            r_avg_labels = list(role_avg.keys())
            r_avg_vals = list(role_avg.values())
            bar_colors = ['#22c55e' if v >= 70 else '#f59e0b' if v >= 40 else '#ef4444' for v in r_avg_vals]

            fig, ax = plt.subplots(figsize=(6, max(3.5, len(r_avg_labels) * 0.5)))
            _light_style(ax, fig)
            bars = ax.barh(r_avg_labels, r_avg_vals, color=bar_colors, height=0.6, edgecolor='none')
            for bar, val in zip(bars, r_avg_vals):
                ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height() / 2, f"{val}%",
                        va='center', color='#334155', fontsize=9, fontweight='bold')
            ax.set_title("Average Score by Role", fontsize=12, fontweight='bold', pad=10)
            ax.set_xlim(0, 105)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            fig.tight_layout()
            _render_fig(fig)
        else:
            st.info("No role data available yet.")
