"""Shortlist page."""

import pandas as pd
import streamlit as st

from scoring.ats import classify_candidate_status
from ui.components import render_quick_view_block, render_why_score_block


def render_shortlist_workspace():
    """
    One place to go from 'AI screened a pile of resumes' to 'recruiter made
    a final call' — combines bulk shortlisting (feature 1) with reviewing,
    comparing, and deciding on the finalists (feature 4). Reuses existing
    fields only: ats_score, classify_candidate_status(), match_result,
    ai_evaluation, and the existing recruiter_decision/notes/reason fields.
    No new scoring, no new AI calls, no new agents.
    """
    st.header("Shortlist Workspace")
    candidates = st.session_state.candidates
    if not candidates:
        st.info("No candidates yet. Run an analysis in 'Candidate Evaluation' first.")
        return

    min_required = st.session_state.min_skill_match
    shortlist_th = st.session_state.shortlist_score_threshold
    hold_th = st.session_state.hold_score_threshold
    reject_th = st.session_state.reject_score_threshold

    def auto_status(c):
        matched_count = c.get("matched_skill_count", len(c.get("match_result", {}).get("matched_skills", [])))
        return classify_candidate_status(matched_count, min_required, c["ats_score"], shortlist_th, hold_th, reject_th)

    # -------------------------------------------------
    # SECTION 1 — BULK SCREENING & SHORTLISTING
    # AI already scored every candidate; this surfaces the ones that meet
    # your current criteria and haven't been decided on yet, and lets you
    # act on all of them in one click instead of one at a time.
    # -------------------------------------------------
    st.markdown("### 🎯 Bulk Screening — AI-Qualified Candidates")
    st.caption(
        f"Candidates meeting your current criteria (≥{min_required} matched skills, "
        f"≥{shortlist_th}% match score — set in Candidate Evaluation → Step 3) that "
        f"you haven't made a final decision on yet."
    )

    undecided = [c for c in candidates if c.get("recruiter_decision", "Not Decided") == "Not Decided"]
    ai_qualified = sorted(
        [c for c in undecided if auto_status(c) == "Shortlisted"],
        key=lambda x: x["ats_score"], reverse=True
    )

    if ai_qualified:
        preview_rows = [{
            "Name": c["name"], "Score": f"{c['ats_score']}%",
            "Matched Skills": c.get("matched_skill_count", len(c.get("match_result", {}).get("matched_skills", []))),
            "Role": c["best_role"]
        } for c in ai_qualified[:15]]
        st.dataframe(pd.DataFrame(preview_rows), use_container_width=True, hide_index=True)
        if len(ai_qualified) > 15:
            st.caption(f"...and {len(ai_qualified) - 15} more.")

        col_a, col_b = st.columns([1, 2])
        with col_a:
            if st.button(f"✅ Shortlist all {len(ai_qualified)} qualifying candidates", key="bulk_shortlist_qualified", type="primary"):
                for c in ai_qualified:
                    c["recruiter_decision"] = "Shortlist"
                st.success(f"Shortlisted {len(ai_qualified)} candidate(s).")
                st.rerun()
        with col_b:
            top_n = st.number_input("...or just shortlist my top N by score", min_value=1, max_value=max(1, len(undecided)), value=min(5, max(1, len(undecided))), key="bulk_top_n")
            if st.button(f"Shortlist Top {top_n}", key="bulk_shortlist_top_n"):
                top_candidates = sorted(undecided, key=lambda x: x["ats_score"], reverse=True)[:int(top_n)]
                for c in top_candidates:
                    c["recruiter_decision"] = "Shortlist"
                st.success(f"Shortlisted top {len(top_candidates)} candidate(s) by score.")
                st.rerun()
    else:
        st.info("No undecided candidates currently meet your shortlist criteria — either everyone's been decided on, or none qualify yet.")

    st.markdown("---")

    # -------------------------------------------------
    # SECTION 2 — REVIEW, COMPARE, DECIDE
    # Everyone currently "in play" (Shortlist or On Hold) — the actual
    # working set a recruiter is choosing between, as opposed to the full
    # candidate pool.
    # -------------------------------------------------
    st.markdown("### 📋 Your Shortlist — Review & Decide")
    in_play = [c for c in candidates if c.get("recruiter_decision") in ("Shortlist", "On Hold")]
    in_play = sorted(in_play, key=lambda x: x["ats_score"], reverse=True)

    if not in_play:
        st.info("Nothing here yet — use the bulk actions above, or set a candidate's decision to Shortlist/On Hold in the Candidates page.")
        return

    filter_choice = st.radio("Show", ["Shortlist + On Hold", "Shortlist only"], horizontal=True, key="workspace_filter")
    if filter_choice == "Shortlist only":
        in_play = [c for c in in_play if c["recruiter_decision"] == "Shortlist"]

    st.caption(f"{len(in_play)} candidate(s) in your working shortlist.")

    # Compact side-by-side comparison table (distinct from the full visual
    # Comparison page's grouped bar chart — this is a quick scan table for
    # the working shortlist specifically, not a replacement for it).
    if len(in_play) >= 2:
        st.markdown("**Quick comparison**")
        compare_rows = []
        for c in in_play:
            match = c.get("match_result", {})
            compare_rows.append({
                "Name": c["name"],
                "Score": f"{c['ats_score']}%",
                "Required Skills": f"{len(match.get('matched_skills', []))}/{len(match.get('matched_skills', [])) + len(match.get('missing_skills', []))}",
                "Preferred Skills": f"{len(match.get('preferred_matched_skills', []))}/{len(match.get('preferred_matched_skills', [])) + len(match.get('preferred_missing_skills', []))}",
                "Experience (yrs)": c["resume_data"].get("experience_years", 0),
                "Decision": c["recruiter_decision"],
            })
        st.dataframe(pd.DataFrame(compare_rows), use_container_width=True, hide_index=True)
        csv = pd.DataFrame(compare_rows).to_csv(index=False).encode("utf-8")
        st.download_button("Download Shortlist Summary", csv, "shortlist_workspace.csv", "text/csv")

    st.markdown("**Individual review**")
    for c in in_play:
        with st.expander(f"{c['name']} — {c['ats_score']}% — {c['best_role']} — currently: {c['recruiter_decision']}"):
            render_quick_view_block(c)
            with st.expander("Why this score?"):
                render_why_score_block(c)

            decision_options = ["Shortlist", "On Hold", "Reject", "Not Decided"]
            new_decision = st.selectbox(
                "Final Decision", decision_options,
                index=decision_options.index(c["recruiter_decision"]) if c["recruiter_decision"] in decision_options else 0,
                key=f"ws_decision_{c['id']}"
            )
            notes = st.text_area("Notes", value=c["recruiter_notes"], key=f"ws_notes_{c['id']}")
            reason = st.text_area("Decision Reason", value=c["recruiter_reason"], key=f"ws_reason_{c['id']}")
            if st.button("Save", key=f"ws_save_{c['id']}"):
                c["recruiter_decision"] = new_decision
                c["recruiter_notes"] = notes
                c["recruiter_reason"] = reason
                st.success("Saved.")
                st.rerun()
