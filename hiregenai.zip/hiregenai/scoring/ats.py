"""ATS score computation, status classification and weight rebalancing."""




# -------------------------------------------------
# ATS SCORE
# -------------------------------------------------
def compute_ats_score(ats_breakdown, weights):
    if not ats_breakdown:
        return 0.0
    total = 0.0
    for key, weight in weights.items():
        total += ats_breakdown.get(key, 0) * (weight / 100.0)
    return round(total, 2)


def classify_candidate_status(matched_count, min_required, score, shortlist_th, hold_th, reject_th):
    """
    Single source of truth for the Shortlisted / AI Evaluated / Rejected
    classification, based purely on the deterministic score + matched-skill
    count — no LLM involved. Used both at analysis time (evaluate_candidate,
    stored as candidate['status']) and live in the Shortlist Workspace,
    which recomputes this fresh against whatever thresholds are currently
    set (so it stays correct even if the recruiter adjusts thresholds or
    weights after the batch was analyzed, rather than relying on the
    possibly-stale value stored at analysis time).
    """
    if matched_count >= min_required and score >= shortlist_th:
        return "Shortlisted"
    elif matched_count >= min_required and score >= hold_th:
        return "AI Evaluated"
    elif matched_count < min_required and score < reject_th:
        return "Rejected"
    else:
        return "AI Evaluated"


def rebalance_weights(changed_key, new_value, weights):
    """Adjust remaining weights so total stays 100."""
    weights = dict(weights)
    weights[changed_key] = new_value
    keys = list(weights.keys())
    others = [k for k in keys if k != changed_key]
    if not others:
        return weights
    current_total = sum(weights.values())
    diff = 100 - current_total
    if diff == 0:
        return weights
    # Distribute diff proportionally
    other_total = sum(weights[k] for k in others)
    if other_total == 0:
        share = diff / len(others)
        for k in others:
            weights[k] = max(0, min(100, weights[k] + share))
    else:
        for k in others:
            weights[k] = max(0, min(100, weights[k] + diff * (weights[k] / other_total)))
    # Normalize to exactly 100
    total = sum(weights.values())
    if total != 100:
        weights[others[0]] += 100 - total
    return {k: round(weights[k], 1) for k in keys}
