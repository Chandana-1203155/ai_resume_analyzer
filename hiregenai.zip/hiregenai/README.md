# HireGenAI (modular)

AI hiring-intelligence platform, refactored from a single `app.py` into modules.
Behaviour, UI, prompts, scoring and the AI provider (OpenAI via LangChain/LangGraph) are unchanged.
All data lives in `st.session_state` only (nothing is persisted).

## Run
```bash
pip install -r requirements.txt
cp .env.example .env        # then put your own OPENAI_API_KEY in it
streamlit run app.py
```

## Layout
| Path | Responsibility |
|---|---|
| `app.py` | Entry point: page config, API-key check, styles, session init, sidebar + routing |
| `config.py` | `.env` loading, model name, limits, `SCORING_LOGIC_VERSION`, `BREAKDOWN_LABELS` |
| `models/` | Pydantic schemas (`schemas.py`), LangGraph `HiringState` (`state.py`) |
| `state/session.py` | `init_session`, `assign_job_id` |
| `ai/llm.py` | Lazy `get_llm()` (same ChatOpenAI settings) + `safe_llm_invoke` |
| `ai/security.py` | Prompt-injection detection / untrusted-data wrapping |
| `ai/agents.py` | `resume_parser`, `jd_analyzer`, `ai_evaluation_agent`, `ai_recommendation_agent` |
| `ai/graphs.py` | Compiled LangGraph graphs |
| `parsing/` | PDF/DOCX/TXT/ZIP extraction (`file_extraction.py`), optional OCR (`ocr.py`) |
| `scoring/` | Deterministic scoring (`deterministic.py`), ATS score / status / weights (`ats.py`) |
| `services/candidate_pipeline.py` | `evaluate_candidate`, `compute_cache_key` |
| `utils/hashing.py` | Content / resume hashes |
| `ui/` | `styles.py`, `helpers.py`, `components.py`, and one file per page in `ui/pages/` |

## The one intentional code change
The `ChatOpenAI` client used to be created at import time. It is now created on first use
through `ai.llm.get_llm()` (identical model, temperature, timeout, retries), so the friendly
"missing OPENAI_API_KEY" message in `app.py` can appear before anything reads the key.
The four agents call `get_llm()` instead of the old global `llm`.
