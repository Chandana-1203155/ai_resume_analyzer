"""Streamlit session-state initialisation (in-memory only; nothing is persisted)."""

import hashlib

import streamlit as st

from config import DEFAULT_MAX_RESUMES


# -------------------------------------------------
# IN-MEMORY HELPERS
# All application data lives only in st.session_state for the current
# Streamlit session. Nothing is written to disk; a restart/new session
# starts empty.
# -------------------------------------------------
def assign_job_id(job):
    """Return a copy of the job dict with a stable in-memory id."""
    job = dict(job)
    job["id"] = job.get("id") or hashlib.md5(job.get("text", "").encode()).hexdigest()[:12]
    return job


# -------------------------------------------------
# SESSION STATE
# -------------------------------------------------
def init_session():
    defaults = {
        "candidates": [],
        "jobs": [],
        "selected_candidates": [],
        "weights": {
            "skills": 30,
            "experience": 20,
            "education": 15,
            "projects": 10,
            "certifications": 10,
            "keywords": 10,
            "resume_quality": 5
        },
        "min_skill_match": 5,
        "shortlist_score_threshold": 70,
        "hold_score_threshold": 40,
        "reject_score_threshold": 30,
        "processing_stats": {"processed": 0, "skipped": 0, "failed": 0},
        "active_section": "Dashboard",
        "jd_upload_key": 0,
        "resume_upload_key": 0,
        "jd_sources": [],
        "resume_files": [],
        "analysis_complete": False,
        "analysis_history": [],
        "analysis_errors": [],
        "decision_history": [],
        "resume_cache": {},
        # Caps how many resumes the app will hold/analyze at once. Every
        # resume costs real OpenAI API tokens (one call to extract resume
        # data + one call for the AI evaluation, per resume), so this is a
        # simple, direct way to control spend. Adjustable in Settings —
        # the env var only sets the starting default.
        "max_resumes_limit": DEFAULT_MAX_RESUMES,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value
