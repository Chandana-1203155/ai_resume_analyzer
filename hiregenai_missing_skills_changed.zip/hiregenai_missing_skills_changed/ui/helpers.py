"""Small presentational helpers."""

import base64
import html

from scoring.deterministic import (
    candidate_related_skills,
    candidate_skill_gaps,
    candidate_unverified_skills,
)


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def status_color(status):
    return {
        "New": "#64748b",
        "AI Evaluated": "#38bdf8",
        "Shortlisted": "#22c55e",
        "On Hold": "#f59e0b",
        "Rejected": "#ef4444",
    }.get(status, "#64748b")


def decision_color(decision):
    return {
        "Shortlist": "#22c55e",
        "On Hold": "#f59e0b",
        "Reject": "#ef4444"
    }.get(decision, "#64748b")


def skill_gap_html(candidate, limit=None):
    """HTML for a candidate's skill gaps, shared by every results view.

    Missing skills are shown first (optionally limited, with a "+N more"
    marker so the list is never silently cut). Skills the resume only partly
    covers, and skills that could not be verified, are shown separately so
    they are not mistaken for genuinely missing skills.
    """
    missing = candidate_skill_gaps(candidate)
    shown = missing if limit is None else missing[:limit]
    text = ", ".join(html.escape(s) for s in shown) or "None"
    if limit is not None and len(missing) > limit:
        text += f" <span style='color:#64748b;'>(+{len(missing) - limit} more)</span>"
    parts = [text]

    related = candidate_related_skills(candidate)
    if related:
        parts.append(
            "<div style='color:#64748b;'>≈ Related skill only: "
            + ", ".join(html.escape(s) for s in related)
            + "</div>"
        )
    unverified = candidate_unverified_skills(candidate)
    if unverified:
        parts.append(
            "<div style='color:#b45309;'>? Could not verify: "
            + ", ".join(html.escape(s) for s in unverified)
            + "</div>"
        )
    return "".join(parts)


def get_resume_preview_html(candidate):
    file_type = candidate.get("file_type", "txt")
    content = candidate.get("file_content", b"")
    if file_type == "pdf" and content:
        b64 = base64.b64encode(content).decode()
        return f'<iframe src="data:application/pdf;base64,{b64}" width="100%" height="500px" style="border:none;"></iframe>'
    return None
