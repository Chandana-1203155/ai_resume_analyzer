"""Candidates page."""

import pandas as pd
import streamlit as st

from config import BREAKDOWN_LABELS
from services.decisions import set_recruiter_decision
from ui.components import render_quick_view_block, render_why_score_block
from ui.helpers import get_resume_preview_html


def render_candidates():
    st.header("Candidates")
    candidates = st.session_state.candidates
    if not candidates:
        st.info("No candidates yet. Evaluate resumes in the 'Candidate Evaluation' section.")
        return

    # Global rank (position among ALL screened candidates, not just the
    # filtered subset below) — used by the Quick View tab so "Rank #3"
    # means something consistent regardless of which filters are active.
    global_rank = {
        c["id"]: i + 1
        for i, c in enumerate(sorted(candidates, key=lambda x: x["ats_score"], reverse=True))
    }
    total_candidates = len(candidates)

    # Search and filters
    st.subheader("Search & Filters")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        search = st.text_input("Search by name, skill, keyword, or role", key="search")
    with col2:
        role_filter = st.text_input("Job Role", key="role_filter")
    with col3:
        decision_filter = st.multiselect("Recruiter Decision", options=["Not Decided", "Shortlist", "On Hold", "Reject"], default=[], key="decision_filter")

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        min_score = st.number_input("Min Match Score", 0.0, 100.0, 0.0, key="min_score")
    with c2:
        max_score = st.number_input("Max Match Score", 0.0, 100.0, 100.0, key="max_score")
    with c3:
        skill_filter = st.text_input("Skill contains", key="skill_filter")
    with c4:
        top_n = st.selectbox("Show Top", options=["All", "Top 5", "Top 10", "Top 20"], index=0, key="top_n")

    filtered = candidates[:]
    if search:
        s = search.lower()
        filtered = [c for c in filtered if s in c["name"].lower() or any(s in skill.lower() for skill in c["resume_data"].get("skills", [])) or s in c["text"].lower() or s in c["best_role"].lower()]
    if decision_filter:
        filtered = [c for c in filtered if c["recruiter_decision"] in decision_filter]
    if role_filter:
        filtered = [c for c in filtered if role_filter.lower() in c["best_role"].lower()]
    if skill_filter:
        filtered = [c for c in filtered if any(skill_filter.lower() in skill.lower() for skill in c["resume_data"].get("skills", []))]
    filtered = [c for c in filtered if min_score <= c["ats_score"] <= max_score]
    filtered = sorted(filtered, key=lambda x: x["ats_score"], reverse=True)

    if top_n == "Top 5":
        filtered = filtered[:5]
    elif top_n == "Top 10":
        filtered = filtered[:10]
    elif top_n == "Top 20":
        filtered = filtered[:20]

    st.write(f"Showing {len(filtered)} of {len(candidates)} candidates")

    # Table
    table_data = []
    for c in filtered:
        table_data.append({
            "Name": c["name"],
            "Match Score": f"{c['ats_score']}%",
            "Best Role": c["best_role"],
            "AI Recommendation": c["ai_recommendation"].get("decision", "On Hold"),
            "Recruiter Decision": c["recruiter_decision"],
        })
    df = pd.DataFrame(table_data)
    st.dataframe(df, use_container_width=True)

    # Bulk compare selection
    selected_ids = st.multiselect("Select candidates for comparison", options=[c["id"] for c in candidates], key="compare_select")
    for c in st.session_state.candidates:
        c["selected_for_comparison"] = c["id"] in selected_ids

    # Expandable details
    st.subheader("Candidate Details")
    for c in filtered:
        with st.expander(f"{c['name']} — Match Score {c['ats_score']}% — {c['best_role']}"):
            if c.get("injection_flag"):
                st.warning(
                    "⚠️ This resume contains phrasing that resembles an attempt to "
                    "instruct the AI (e.g. \"ignore previous instructions\"). Scoring "
                    "in this app is deterministic and not influenced by such text, "
                    "but flagging it here for recruiter awareness."
                )
            tabs = st.tabs(["Quick View", "Overview", "Score Breakdown", "Why This Score?", "Skills", "AI Recommendation", "Recruiter Decision", "Resume Preview"])

            with tabs[0]:
                render_quick_view_block(c, rank=global_rank.get(c["id"]), total=total_candidates)

            with tabs[1]:
                st.markdown(f"**Email:** {c['resume_data'].get('email', 'N/A')}")
                st.markdown(f"**Phone:** {c['resume_data'].get('phone', 'N/A')}")
                st.markdown(f"**Experience:** {c['resume_data'].get('experience_years', 0)} years (professional employment only)")
                internship_yrs = c['resume_data'].get('internship_experience_years', 0)
                if internship_yrs:
                    st.caption(f"Plus {internship_yrs} year(s) of internship experience — shown separately, not counted toward the Experience score.")
                st.markdown(f"**Education:** {c['resume_data'].get('education', 'N/A')} ({c['resume_data'].get('education_level', '')})")
                st.markdown(f"**Professional Summary:** {c['ai_evaluation'].get('summary', '')}")
                st.markdown(f"**Profile Completeness Score:** {c['ats_breakdown'].get('resume_quality', 0)}%")

            with tabs[2]:
                breakdown = c["ats_breakdown"]
                weights = st.session_state.weights
                for key in ["skills", "experience", "education", "projects", "certifications", "keywords", "resume_quality"]:
                    score = breakdown.get(key, 0)
                    weight = weights.get(key, 0)
                    weighted = round(score * weight / 100, 2)
                    st.write(f"**{BREAKDOWN_LABELS.get(key, key.replace('_', ' ').title())}:** {score}% (weight {weight}%, contribution {weighted}%)")
                st.caption(
                    "ℹ️ **Education** and **Certifications** scores are simplified heuristic "
                    "estimates, not a precise match against the job's actual requirements — "
                    "the job description text doesn't currently distinguish 'required "
                    "certifications' from general keywords, and education level comparison "
                    "uses a coarse High School < Bachelor < Master < Doctorate ranking. "
                    "Use these two scores as a rough signal, and verify manually before "
                    "ruling a candidate in or out on either one."
                )
                st.progress(c["ats_score"] / 100.0)
                st.write(f"**Final Candidate Match Score:** {c['ats_score']}%")

            with tabs[3]:
                render_why_score_block(c)

            with tabs[4]:
                st.write("**Matched Skills:**", ", ".join(c["ai_evaluation"].get("matched_skills", [])))
                st.write("**Missing Skills:**", ", ".join(c["ai_evaluation"].get("missing_skills", [])))
                st.write("**Strengths:**")
                for s in c["ai_evaluation"].get("strengths", []):
                    st.write(f"- {s}")
                st.write("**Weaknesses:**")
                for w in c["ai_evaluation"].get("weaknesses", []):
                    st.write(f"- {w}")
                st.write("**Skill Gap Analysis:**", c["ai_evaluation"].get("skill_gap_analysis", ""))

            with tabs[5]:
                rec = c["ai_recommendation"]
                st.markdown(f"**AI Decision:** {rec.get('decision', 'On Hold')}")
                st.markdown(f"**AI Assessment Strength:** {rec.get('confidence', 0)}% (qualitative indicator, not a statistical probability)")
                st.markdown(f"**Reason:** {rec.get('reason', '')}")

            with tabs[6]:
                decision_options = ["Not Decided","Shortlist", "On Hold", "Reject"]
                new_decision = st.selectbox("Recruiter Decision", decision_options, index=decision_options.index(c["recruiter_decision"]) if c["recruiter_decision"] in decision_options else 0, key=f"decision_{c['id']}")
                notes = st.text_area("Recruiter Notes", value=c["recruiter_notes"], key=f"notes_{c['id']}")
                reason = st.text_area("Decision Reason", value=c["recruiter_reason"], key=f"reason_{c['id']}")
                if st.button("Save Decision", key=f"save_{c['id']}"):
                    set_recruiter_decision(c, new_decision, via="candidates_save")
                    c["recruiter_notes"] = notes
                    c["recruiter_reason"] = reason
                    st.success("Decision saved.")

                st.markdown("---")
                st.caption(
                    "Remove this candidate's analysis (e.g. to re-run them after a "
                    "scoring/extraction fix, or if the resume was uploaded by mistake). "
                    "The original resume file stays in your uploads — re-run 'Analyze "
                    "Candidates' afterward to get a fresh result."
                )
                if st.button("🗑️ Remove candidate & re-analyze next run", key=f"remove_candidate_{c['id']}"):
                    st.session_state.candidates = [
                        cand for cand in st.session_state.candidates if cand["id"] != c["id"]
                    ]
                    st.success(f"Removed {c['name']}. Re-run 'Analyze Candidates' in Candidate Evaluation to re-score them.")
                    st.rerun()

            
            with tabs[7]:
                preview = get_resume_preview_html(c)
                if preview:
                    st.markdown(preview, unsafe_allow_html=True)
                else:
                    st.text_area("Resume Text", c["text"], height=400)
