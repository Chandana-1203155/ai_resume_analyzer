"""Decision lists: apply AI recommendations or manual decisions, one by one or in bulk.

Rendered inside the Shortlist Workspace page. Lists are derived from each
candidate's ``recruiter_decision`` - so changing a decision automatically moves
the candidate to the matching list. The AI recommendation is shown next to the
recruiter decision but is never modified; every change is logged in
``st.session_state.decision_history`` (see services/decisions.py).
"""

import html

import pandas as pd
import streamlit as st

from services.decisions import (
    ACTIONABLE_DECISIONS,
    ALL_DECISIONS,
    NOT_DECIDED,
    ai_already_applied,
    apply_ai_recommendation,
    apply_manual_decision,
    bulk_apply_ai,
    bulk_apply_manual,
    current_decision,
    decision_provenance,
    format_timestamp,
    get_ai_decision,
    get_history,
    preview_ai,
    preview_manual,
    source_label,
)

LIST_ORDER = ["Shortlist", "On Hold", "Reject", NOT_DECIDED]
LIST_LABEL = {"Shortlist": "Shortlisted", "On Hold": "On Hold", "Reject": "Rejected", NOT_DECIDED: "Not Decided"}
COLS = [0.6, 3.0, 1.7, 2.0, 2.0, 1.9]


# -------------------------------------------------
# Helpers
# -------------------------------------------------
def _badge(decision):
    cls = {"Shortlist": "badge-green", "Reject": "badge-red", "On Hold": "badge-yellow"}.get(decision, "badge-blue")
    return f"<span class='badge {cls}'>{html.escape(str(decision))}</span>"


def _members(list_name):
    members = [c for c in st.session_state.candidates if current_decision(c) == list_name]
    return sorted(members, key=lambda x: x["ats_score"], reverse=True)


def _selected(list_name):
    return [c for c in _members(list_name) if st.session_state.get(f"dl_sel_{c['id']}", False)]


def _find(candidate_id):
    return next((c for c in st.session_state.candidates if c["id"] == candidate_id), None)


def _flash(level, message):
    st.session_state["dl_flash"] = (level, message)


def _reset_selection(candidate_ids):
    for cid in candidate_ids:
        st.session_state[f"dl_sel_{cid}"] = False


def _outcome_text(result):
    labels = [("moved", "moved"), ("confirmed", "confirmed in place"),
              ("already_applied", "already applied"), ("unchanged", "unchanged"),
              ("no_recommendation", "had no AI recommendation")]
    return ", ".join(f"{result[k]} {text}" for k, text in labels if result.get(k))


# -------------------------------------------------
# Callbacks (run before the page re-renders, so widget state can be reset safely)
# -------------------------------------------------
def _cancel_pending():
    st.session_state.pop("dl_pending", None)


def _request_confirmation(kind, list_name, target=None):
    chosen = _members(list_name) if kind == "ai_all" else _selected(list_name)
    if not chosen:
        _flash("warning", "No candidates to apply this to.")
        return
    st.session_state["dl_pending"] = {
        "kind": kind, "list": list_name, "target": target, "ids": [c["id"] for c in chosen],
    }


def _confirm_pending():
    pending = st.session_state.pop("dl_pending", None)
    if not pending:
        return
    by_id = {c["id"]: c for c in st.session_state.candidates}
    chosen = [by_id[i] for i in pending["ids"] if i in by_id]
    history = get_history()
    if pending["kind"] in ("ai_all", "ai_selected"):
        via = "bulk_ai_list" if pending["kind"] == "ai_all" else "bulk_ai_selected"
        result = bulk_apply_ai(chosen, history, via=via)
        message = f"Applied AI recommendations to {len(chosen)} candidate(s): {_outcome_text(result)}."
    else:
        target = pending["target"]
        result = bulk_apply_manual(chosen, target, history, via="bulk_manual_selected")
        message = f"Set {len(chosen)} candidate(s) to {target}: {_outcome_text(result)}."
    _reset_selection(pending["ids"])
    _flash("success", message)


def _select_all(list_name):
    for c in _members(list_name):
        st.session_state[f"dl_sel_{c['id']}"] = True


def _clear_selection(list_name):
    _reset_selection([c["id"] for c in _members(list_name)])


def _apply_ai_single(candidate_id):
    c = _find(candidate_id)
    if c is None:
        return
    result = apply_ai_recommendation(c, get_history(), via="individual_ai")
    _cancel_pending()
    _reset_selection([candidate_id])
    if result == "moved":
        _flash("success", f"{c['name']}: applied AI recommendation - now {current_decision(c)}.")
    elif result == "confirmed":
        _flash("success", f"{c['name']}: already {current_decision(c)}; recorded as accepted AI recommendation.")
    elif result == "already_applied":
        _flash("info", f"{c['name']}: AI recommendation was already applied.")
    else:
        _flash("warning", f"{c['name']}: no AI recommendation available.")


def _on_manual_change(candidate_id):
    c = _find(candidate_id)
    new = st.session_state.get(f"dl_set_{candidate_id}")
    if c is None or new not in ALL_DECISIONS:
        return
    old = current_decision(c)
    result = apply_manual_decision(c, new, get_history(), via="individual_manual")
    _cancel_pending()
    if result == "moved":
        _reset_selection([candidate_id])
        ai = get_ai_decision(c)
        note = " (overrides the AI recommendation)" if ai is not None and ai != new else ""
        _flash("success", f"{c['name']}: {old} -> {new}{note}.")


# -------------------------------------------------
# Rendering
# -------------------------------------------------
def _render_pending(active, history):
    pending = st.session_state.get("dl_pending")
    if not pending or pending["list"] != active:
        return
    by_id = {c["id"]: c for c in st.session_state.candidates}
    chosen = [by_id[i] for i in pending["ids"] if i in by_id]
    if not chosen:
        _cancel_pending()
        return
    n = len(chosen)
    where = LIST_LABEL[active]
    if pending["kind"] in ("ai_all", "ai_selected"):
        scope = f"all {n}" if pending["kind"] == "ai_all" else f"the {n} selected"
        st.warning(
            f"**Confirm:** apply each candidate's own AI recommendation to {scope} candidate(s) "
            f"in **{where}**? Each candidate's recruiter decision will be updated to match their AI recommendation."
        )
        rows = preview_ai(chosen, history)
        confirm_label = f"✅ Apply AI to {n} candidate(s)"
    else:
        target = pending["target"]
        box = st.error if target == "Reject" else st.warning
        box(f"**Confirm:** set {n} selected candidate(s) in **{where}** to **{target}**?"
            + (" Rejecting candidates in bulk is hard to spot-check, so please review the list below." if target == "Reject" else ""))
        rows = preview_manual(chosen, target)
        confirm_label = f"Yes, reject {n} candidate(s)" if target == "Reject" else f"✅ Set {n} to {target}"
    st.dataframe(pd.DataFrame(rows[:50]), hide_index=True)
    if len(rows) > 50:
        st.caption(f"...and {len(rows) - 50} more.")
    b1, b2, _ = st.columns([2, 1, 3])
    b1.button(confirm_label, key="dl_confirm", type="primary", on_click=_confirm_pending)
    b2.button("Cancel", key="dl_cancel", on_click=_cancel_pending)


def _render_toolbar(active):
    members = _members(active)
    n = len(members)
    k = len(_selected(active))
    st.caption(f"{n} candidate(s) in this list · {k} selected")

    a1, a2, a3, a4 = st.columns([2, 2, 1.2, 1.4])
    a1.button(f"🤖 Apply AI recommendations to all ({n})", key=f"dl_ai_all_{active}", disabled=(n == 0),
              on_click=_request_confirmation, args=("ai_all", active))
    a2.button(f"🤖 Apply AI to selected ({k})", key=f"dl_ai_sel_{active}", disabled=(k == 0),
              on_click=_request_confirmation, args=("ai_selected", active))
    a3.button("Select all", key=f"dl_selall_{active}", disabled=(n == 0), on_click=_select_all, args=(active,))
    a4.button("Clear selection", key=f"dl_clear_{active}", disabled=(k == 0), on_click=_clear_selection, args=(active,))

    m1, m2, m3, _ = st.columns([1.4, 1.4, 1.4, 2])
    for col, target, label in ((m1, "Shortlist", "Shortlist Selected"), (m2, "On Hold", "On Hold Selected"),
                               (m3, "Reject", "Reject Selected")):
        col.button(label, key=f"dl_man_{target}_{active}", disabled=(k == 0 or target == active),
                   on_click=_request_confirmation, args=("manual_selected", active, target))


def _render_rows(active, history):
    members = _members(active)
    if not members:
        st.info(f"No candidates in {LIST_LABEL[active]} right now.")
        return
    head = st.columns(COLS)
    for col, text in zip(head, ["", "Candidate", "AI recommendation", "Recruiter decision", "Set decision", "AI shortcut"]):
        col.caption(text)
    for c in members:
        cid = c["id"]
        cur = current_decision(c)
        ai = get_ai_decision(c)
        rec = c.get("ai_recommendation") or {}
        cols = st.columns(COLS)

        cols[0].checkbox(f"Select {c['name']}", key=f"dl_sel_{cid}", label_visibility="collapsed")

        cols[1].markdown(
            f"<div style='font-weight:600;'>{html.escape(str(c['name']))}</div>"
            f"<div style='color:#64748b;font-size:.8rem;'>{c['ats_score']}% · {html.escape(str(c.get('best_role', '')))}</div>",
            unsafe_allow_html=True,
        )

        conf = rec.get("confidence")
        cols[2].markdown(
            (_badge(ai) if ai else "<span style='color:#94a3b8;'>—</span>")
            + (f" <span style='color:#64748b;font-size:.75rem;'>{conf}%</span>" if ai and conf is not None else ""),
            unsafe_allow_html=True,
        )

        prov = decision_provenance(c, history)
        prov_html = (f"<div style='color:#64748b;font-size:.72rem;margin-top:2px;'>{html.escape(prov['label'])} · "
                     f"{html.escape(format_timestamp(prov['timestamp']))}</div>") if prov else ""
        cols[3].markdown(_badge(cur) + prov_html, unsafe_allow_html=True)

        # Keep the selector in step with the real decision (it may have been
        # changed by a bulk action or another page since the last run).
        options = list(ACTIONABLE_DECISIONS) if cur != NOT_DECIDED else [NOT_DECIDED, *ACTIONABLE_DECISIONS]
        st.session_state[f"dl_set_{cid}"] = cur
        cols[4].selectbox(f"Decision for {c['name']}", options, key=f"dl_set_{cid}",
                          label_visibility="collapsed", on_change=_on_manual_change, args=(cid,))

        applied = ai_already_applied(c, history)
        label = "✓ AI applied" if applied else (f"Use AI: {ai}" if ai else "No AI rec")
        cols[5].button(label, key=f"dl_ai_{cid}", disabled=(ai is None or applied),
                       help=(rec.get("reason") or None), on_click=_apply_ai_single, args=(cid,))


def _render_history(history):
    with st.expander(f"📜 Decision history ({len(history)})"):
        if not history:
            st.caption("No decisions recorded yet this session.")
            return
        rows = [{
            "When": format_timestamp(e["timestamp"]),
            "Candidate": e["candidate_name"],
            "From": e["from_decision"],
            "To": e["to_decision"],
            "How": source_label(e),
            "AI recommended": e["ai_decision"] or "-",
            "Action": e["via"],
        } for e in reversed(history)]
        df = pd.DataFrame(rows)
        st.dataframe(df, hide_index=True)
        st.download_button("Download Decision History", df.to_csv(index=False).encode("utf-8"),
                           "decision_history.csv", "text/csv", key="dl_history_csv")
        st.caption("History is kept for this session only and is cleared by 'Reset All Data'.")


def render_decision_lists(candidates):
    st.markdown("### 🗂️ Decision Lists — AI Recommendations & Manual Decisions")
    st.caption(
        "Candidates are listed by their current recruiter decision. Apply a candidate's AI recommendation, "
        "or choose a decision yourself — either way the candidate moves to the matching list. "
        "The AI recommendation itself is never changed, and every decision is logged."
    )
    history = get_history()

    flash = st.session_state.pop("dl_flash", None)
    if flash:
        getattr(st, flash[0])(flash[1])

    counts = {d: len(_members(d)) for d in LIST_ORDER}
    active = st.radio("Decision list", LIST_ORDER, horizontal=True, key="dl_active_list",
                      format_func=lambda d: f"{LIST_LABEL[d]} ({counts[d]})",
                      label_visibility="collapsed", on_change=_cancel_pending)

    _render_pending(active, history)
    _render_toolbar(active)
    _render_rows(active, history)
    _render_history(history)
